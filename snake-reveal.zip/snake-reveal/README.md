# Snake Reveal 🐍🖼️

Jogo estilo Snake em que cada movimento revela um pedaço de uma imagem exclusiva.
Frontend em **React + Vite**, backend em **Supabase** (auth, banco, storage, edge functions),
pagamentos via **Stripe** e **Mercado Pago**. PWA responsivo (Android, iPhone, desktop).

## O que já vem pronto

- Jogo Snake completo (teclado + D-pad touch), tabuleiro toroidal, grade que revela a imagem conforme a cobra passa, meta de % revelada para "vencer".
- Autenticação (cadastro, login, sessão persistente) via Supabase Auth.
- Galeria de imagens com filtro por categoria, badges grátis/premium.
- Checkout com pacotes de créditos, assinatura mensal e compra avulsa, escolhendo Stripe ou Mercado Pago.
- Perfil do usuário: créditos, assinatura ativa, histórico de compras, últimas partidas.
- Painel admin: estatísticas (usuários, receita, assinaturas, sessões), upload/gestão de imagens (Supabase Storage), categorias, usuários (créditos, papel, bloqueio), promoções/cupons.
- Schema SQL completo com Row Level Security, views de estatísticas e bucket de storage.
- Edge Functions para criar checkout e para os webhooks de confirmação de pagamento.
- Design system próprio ("Câmara Escura"), dark mode, responsivo, com atenção a `prefers-reduced-motion` e foco de teclado visível.

## O que você precisa configurar antes de rodar

Este é um projeto real, não uma demo — para funcionar de ponta a ponta você precisa
criar as contas e preencher as chaves abaixo. Nada disso pode ser feito por mim
diretamente (são contas e segredos seus).

### 1. Supabase
1. Crie um projeto em https://supabase.com.
2. No **SQL Editor**, rode o arquivo `supabase/migrations/0001_init.sql` inteiro.
3. Em **Storage**, confirme que o bucket `images` foi criado (o script já cria) e está público.
4. Em **Authentication → Providers**, habilite Email (e opcionalmente Google/Apple se quiser login social — o código em `AuthContext.jsx` já tem `signInWithProvider`).
5. Copie `Project URL` e `anon public key` para o `.env` (veja `.env.example`).
6. Torne seu próprio usuário admin: depois de criar sua conta pelo app, rode no SQL Editor:
   ```sql
   update public.profiles set role = 'admin' where id = 'SEU_USER_ID';
   ```

### 2. Stripe
1. Crie conta em https://dashboard.stripe.com.
2. Crie um produto recorrente para a assinatura mensal e copie o `price_id`.
3. Configure os *secrets* das Edge Functions (via Supabase CLI):
   ```bash
   supabase secrets set STRIPE_SECRET_KEY=sk_...
   supabase secrets set STRIPE_PRICE_MENSAL=price_...
   supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
   ```
4. No Dashboard do Stripe, crie um Webhook apontando para
   `https://SEU_PROJETO.functions.supabase.co/stripe-webhook`, escutando
   `checkout.session.completed` e `customer.subscription.deleted`.
5. Coloque a chave pública no `.env` do frontend (`VITE_STRIPE_PUBLISHABLE_KEY`).

### 3. Mercado Pago
1. Crie uma aplicação em https://www.mercadopago.com.br/developers.
2. Configure os secrets:
   ```bash
   supabase secrets set MP_ACCESS_TOKEN=APP_USR-...
   ```
3. Coloque a chave pública no `.env` (`VITE_MERCADOPAGO_PUBLIC_KEY`).
4. A notification_url do webhook já é montada automaticamente pela função `create-checkout`.

### 4. Deploy das Edge Functions
```bash
supabase login
supabase link --project-ref SEU_PROJETO_REF
supabase secrets set SUPABASE_URL=https://SEU_PROJETO.supabase.co SUPABASE_SERVICE_ROLE_KEY=... APP_URL=https://seuapp.com
supabase functions deploy create-checkout
supabase functions deploy stripe-webhook --no-verify-jwt
supabase functions deploy mercadopago-webhook --no-verify-jwt
```

### 5. Rodando localmente
```bash
cp .env.example .env   # preencha com suas chaves
npm install
npm run dev
```

### 6. Ícones do PWA
Coloque seus ícones em `public/icons/` (`icon-192.png`, `icon-512.png`,
`icon-512-maskable.png`) e um `apple-touch-icon.png` em `public/`. O
`vite-plugin-pwa` já está configurado em `vite.config.js` para gerar o
manifest e o service worker no build (`npm run build`).

### 7. Publicando
- **Web**: `npm run build` gera `dist/` — publique em Vercel, Netlify ou similar.
- **Android/iPhone**: como é um PWA instalável, o usuário pode "Adicionar à tela
  de início" direto do navegador. Para lojas (Play Store/App Store), envolva o
  build com Capacitor ou TWA (Trusted Web Activity) — não incluído aqui, mas o
  código é compatível por não usar nada exclusivo de navegador desktop.

## Estrutura do projeto

```
src/
  components/
    Game/       -> motor do jogo, tabuleiro de revelação, HUD, controles touch
    Auth/       -> (fluxos usam context + páginas Login/Register)
    Shop/       -> galeria de imagens e modal de checkout
    Admin/      -> estatísticas, upload de imagens, usuários, categorias, promoções
    Layout/     -> navbar, rotas protegidas (usuário / admin)
  context/      -> AuthContext (sessão, perfil, papel)
  pages/        -> telas roteadas (Home, Play, Gallery, Profile, Admin, Login, Register)
  lib/          -> cliente Supabase
supabase/
  migrations/   -> schema SQL completo (tabelas, RLS, views, storage)
  functions/    -> Edge Functions (checkout, webhooks Stripe/Mercado Pago)
```

## Pontos de atenção / próximos passos sugeridos

- A conversão crédito → preço na compra avulsa (`create-checkout`) está com uma
  fórmula de exemplo (`price_credits * 0.5`) — ajuste para sua régua de preços real,
  idealmente lendo de uma tabela `products` gerenciável pelo admin em vez de fixo no código.
- Aplicação de cupons de promoção ainda não está conectada ao fluxo de checkout —
  a tabela e o CRUD já existem; falta o passo de consultar `promotions` dentro da
  Edge Function `create-checkout` e aplicar o desconto no valor final.
- Geração de thumbnail usa o parâmetro de transformação de imagem do Supabase
  (`?width=...&resize=cover`), disponível no plano Pro do Storage; no plano Free,
  troque por um redimensionamento client-side antes do upload ou uma Edge Function dedicada.
- Testes automatizados não estão incluídos — recomendo Playwright para o fluxo de
  jogo e Vitest para os hooks (`useSnakeGame`).
