import { Routes, Route, NavLink } from 'react-router-dom'
import StatsPanel from '../components/Admin/StatsPanel.jsx'
import ImageUpload from '../components/Admin/ImageUpload.jsx'
import UserManagement from '../components/Admin/UserManagement.jsx'
import CategoriesManager from '../components/Admin/CategoriesManager.jsx'
import PromotionsManager from '../components/Admin/PromotionsManager.jsx'

const TABS = [
  { to: '', label: 'Estatísticas' },
  { to: 'imagens', label: 'Imagens' },
  { to: 'usuarios', label: 'Usuários' },
  { to: 'categorias', label: 'Categorias' },
  { to: 'promocoes', label: 'Promoções' }
]

export default function Admin() {
  return (
    <div className="admin-page">
      <h1 className="display">Painel administrativo</h1>
      <nav className="admin-tabs">
        {TABS.map((t) => (
          <NavLink key={t.to} to={t.to} end={t.to === ''} className="admin-tabs__link">
            {t.label}
          </NavLink>
        ))}
      </nav>

      <div className="admin-content">
        <Routes>
          <Route index element={<StatsPanel />} />
          <Route path="imagens" element={<ImageUpload />} />
          <Route path="usuarios" element={<UserManagement />} />
          <Route path="categorias" element={<CategoriesManager />} />
          <Route path="promocoes" element={<PromotionsManager />} />
        </Routes>
      </div>
    </div>
  )
}
