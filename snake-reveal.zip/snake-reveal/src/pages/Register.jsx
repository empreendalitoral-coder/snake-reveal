import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function Register() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ displayName: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (form.password.length < 6) { setError('A senha precisa ter ao menos 6 caracteres.'); return }
    setLoading(true)
    const { error } = await signUp(form)
    setLoading(false)
    if (error) { setError(traduzErro(error.message)); return }
    setSent(true)
  }

  if (sent) {
    return (
      <div className="auth-page">
        <div className="card auth-card">
          <h1 className="display">Confirme seu e-mail</h1>
          <p>Enviamos um link de confirmação para <strong>{form.email}</strong>. Depois de confirmar, você já pode entrar.</p>
          <button className="btn btn-primary btn-block" onClick={() => navigate('/entrar')}>Ir para o login</button>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-page">
      <form className="card auth-card" onSubmit={handleSubmit}>
        <h1 className="display">Criar conta</h1>
        <p className="auth-card__subtitle">Jogue grátis e desbloqueie imagens exclusivas.</p>

        <div className="field">
          <label htmlFor="name">Nome</label>
          <input id="name" required value={form.displayName}
            onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="email">E-mail</label>
          <input id="email" type="email" required value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="password">Senha</label>
          <input id="password" type="password" required value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>

        {error && <p className="error-text">{error}</p>}

        <button className="btn btn-primary btn-block" disabled={loading}>
          {loading ? 'Criando…' : 'Criar conta'}
        </button>

        <p className="auth-card__footer">
          Já tem conta? <Link to="/entrar">Entrar</Link>
        </p>
      </form>
    </div>
  )
}

function traduzErro(msg) {
  if (msg.includes('already registered')) return 'Este e-mail já está cadastrado.'
  return 'Não foi possível criar a conta. Tente novamente.'
}
