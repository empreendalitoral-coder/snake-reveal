import { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext.jsx'
import SnakeGame from '../components/Game/SnakeGame.jsx'
import Checkout from '../components/Shop/Checkout.jsx'

/**
 * Resolve qual imagem o usuário vai jogar: grátis, já comprada, ou
 * bloqueada (nesse caso mostra o Checkout). Ao vencer o jogo, grava
 * o progresso/desbloqueio (para imagens grátis) ou apenas o recorde
 * de score (para imagens já compradas) na tabela `game_sessions`.
 */
export default function Play() {
  const { imageId } = useParams()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [image, setImage] = useState(null)
  const [access, setAccess] = useState('checking') // checking | granted | denied
  const [showCheckout, setShowCheckout] = useState(false)
  const [loading, setLoading] = useState(true)

  const loadImage = useCallback(async () => {
    setLoading(true)
    let query = supabase.from('images').select('*').eq('is_published', true)
    query = imageId ? query.eq('id', imageId) : query.eq('access_tier', 'free').order('created_at', { ascending: false }).limit(1)
    const { data } = await query.maybeSingle ? await query.maybeSingle() : await query.single()

    if (!data) { setAccess('denied'); setLoading(false); return }
    setImage(data)

    if (data.access_tier === 'free') {
      setAccess('granted')
    } else {
      const { data: purchase } = await supabase
        .from('purchases')
        .select('id')
        .eq('user_id', user.id)
        .eq('image_id', data.id)
        .maybeSingle()
      setAccess(purchase ? 'granted' : 'denied')
    }
    setLoading(false)
  }, [imageId, user])

  useEffect(() => { loadImage() }, [loadImage])

  const handleWin = async (score) => {
    await supabase.from('game_sessions').insert({
      user_id: user.id,
      image_id: image.id,
      score,
      completed: true
    })
    // Progresso de "revelação" concluído fica salvo; o backend também
    // pode conceder créditos bônus por streak diário via trigger/edge function.
  }

  if (loading) return <div className="page-loading">Carregando…</div>
  if (!image) return <div className="page-loading">Nenhuma imagem disponível ainda.</div>

  if (access === 'denied') {
    return (
      <div className="play-locked">
        <img src={image.thumbnail_url} alt={image.title} className="play-locked__thumb" />
        <h2 className="display">{image.title} é uma imagem premium</h2>
        <p className="text-muted">Desbloqueie com créditos ou assinatura para jogar e revelar.</p>
        <button className="btn btn-premium" onClick={() => setShowCheckout(true)}>Desbloquear agora</button>
        {showCheckout && (
          <Checkout imageToUnlock={image} onClose={() => setShowCheckout(false)} />
        )}
      </div>
    )
  }

  return (
    <div className="play-page">
      <SnakeGame image={{ fullUrl: image.full_url, blurredPreviewUrl: image.thumbnail_url }} onWin={handleWin} />
    </div>
  )
}
