import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext.jsx'

export default function Profile() {
  const { user, profile } = useAuth()
  const [purchases, setPurchases] = useState([])
  const [sessions, setSessions] = useState([])
  const [subscription, setSubscription] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      const [{ data: p }, { data: s }, { data: sub }] = await Promise.all([
        supabase.from('purchases').select('id, amount_paid, currency, created_at, images(title, thumbnail_url)').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('game_sessions').select('id, score, completed, created_at, images(title)').eq('user_id', user.id).order('created_at', { ascending: false }).limit(10),
        supabase.from('subscriptions').select('*').eq('user_id', user.id).eq('status', 'active').maybeSingle()
      ])
      setPurchases(p || [])
      setSessions(s || [])
      setSubscription(sub)
      setLoading(false)
    })()
  }, [user])

  if (loading) return <div className="page-loading">Carregando perfil…</div>

  return (
    <div className="profile-page">
      <div className="card profile-summary">
        <h1 className="display">{profile?.display_name}</h1>
        <p className="text-muted">{user.email}</p>
        <div className="profile-summary__stats">
          <div><strong className="mono">{profile?.credits ?? 0}</strong><span>créditos</span></div>
          <div><strong className="mono">{subscription ? 'Ativa' : '—'}</strong><span>assinatura</span></div>
          <div><strong className="mono">{purchases.length}</strong><span>compras</span></div>
        </div>
      </div>

      <section className="profile-section">
        <h2>Histórico de compras</h2>
        {purchases.length === 0 && <p className="text-muted">Nenhuma compra ainda.</p>}
        <ul className="purchase-list">
          {purchases.map((p) => (
            <li key={p.id} className="purchase-list__item">
              <img src={p.images?.thumbnail_url} alt="" />
              <div>
                <strong>{p.images?.title ?? 'Pacote de créditos'}</strong>
                <span className="mono text-muted">
                  {new Date(p.created_at).toLocaleDateString('pt-BR')} · {p.currency} {p.amount_paid}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="profile-section">
        <h2>Progresso recente</h2>
        {sessions.length === 0 && <p className="text-muted">Você ainda não jogou nenhuma partida.</p>}
        <ul className="session-list">
          {sessions.map((s) => (
            <li key={s.id} className="session-list__item">
              <span>{s.images?.title}</span>
              <span className="mono">{s.completed ? '✓ revelada' : 'incompleta'} · {s.score} pts</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  )
}
