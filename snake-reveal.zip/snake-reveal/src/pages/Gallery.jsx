import ImageGallery from '../components/Shop/ImageGallery.jsx'

export default function Gallery() {
  return (
    <div>
      <h1 className="display" style={{ marginBottom: 16 }}>Galeria de imagens</h1>
      <ImageGallery />
    </div>
  )
}
