import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function Home() {
  const { user } = useAuth()
  return (
    <div className="home-hero">
      <span className="mono home-hero__eyebrow">JOGO · GALERIA · RECOMPENSA</span>
      <h1 className="display home-hero__title">
        Cada movimento revela<br /> um pedaço da imagem.
      </h1>
      <p className="home-hero__lead">
        Controle a cobra, cubra o tabuleiro e desbloqueie ilustrações exclusivas.
        Jogue grátis todos os dias ou desbloqueie coleções premium com créditos ou assinatura.
      </p>
      <div className="home-hero__actions">
        <Link to="/galeria" className="btn btn-primary">Ver galeria</Link>
        {!user && <Link to="/cadastro" className="btn btn-ghost">Criar conta grátis</Link>}
      </div>

      <div className="home-hero__board-preview" aria-hidden="true">
        {Array.from({ length: 8 * 8 }).map((_, i) => (
          <div key={i} className="home-hero__tile" style={{ animationDelay: `${(i % 8) * 60 + Math.floor(i / 8) * 40}ms` }} />
        ))}
      </div>
    </div>
  )
}
