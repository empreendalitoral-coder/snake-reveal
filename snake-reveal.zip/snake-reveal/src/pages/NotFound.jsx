import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="page-loading">
      <h1 className="display">404</h1>
      <p>Essa página não existe.</p>
      <Link to="/" className="btn btn-primary">Voltar ao início</Link>
    </div>
  )
}
