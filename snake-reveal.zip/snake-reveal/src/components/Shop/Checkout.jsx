import { useState } from 'react'
import { loadStripe } from '@stripe/stripe-js'
import { supabase } from '../../lib/supabaseClient'
import { useAuth } from '../../context/AuthContext.jsx'

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY)

// Pacotes de crédito e planos de assinatura — em produção, isso viria
// da tabela `products` (gerenciada pelo admin), não hardcoded. Deixado
// aqui como fallback/exemplo de shape de dados.
const CREDIT_PACKS = [
  { id: 'pack_10', credits: 10, price: 9.9, label: '10 créditos' },
  { id: 'pack_30', credits: 30, price: 24.9, label: '30 créditos', highlight: true },
  { id: 'pack_100', credits: 100, price: 69.9, label: '100 créditos' }
]

const PLANS = [
  { id: 'plan_mensal', label: 'Assinatura mensal', price: 19.9, interval: 'mês', perks: ['Imagens premium ilimitadas', 'Sem anúncios', '+20 créditos/mês'] }
]

export default function Checkout({ imageToUnlock, onClose }) {
  const { user } = useAuth()
  const [method, setMethod] = useState('stripe') // 'stripe' | 'mercadopago'
  const [loadingId, setLoadingId] = useState(null)
  const [error, setError] = useState('')

  const handleBuy = async (item, kind) => {
    setError('')
    setLoadingId(item.id)
    try {
      // Chama a Supabase Edge Function que cria a sessão de checkout no
      // provedor escolhido, mantendo as chaves secretas no backend.
      const { data, error: fnError } = await supabase.functions.invoke('create-checkout', {
        body: {
          provider: method,
          kind, // 'credits' | 'subscription' | 'single_image'
          itemId: item.id,
          imageId: imageToUnlock?.id ?? null,
          userId: user.id
        }
      })
      if (fnError) throw fnError
      window.location.href = data.checkoutUrl
    } catch (e) {
      setError('Não foi possível iniciar o pagamento. Tente novamente.')
      console.error(e)
    } finally {
      setLoadingId(null)
    }
  }

  return (
    <div className="checkout-modal-backdrop" onClick={onClose}>
      <div className="checkout-modal card" onClick={(e) => e.stopPropagation()}>
        <button className="checkout-modal__close" onClick={onClose} aria-label="Fechar">✕</button>
        <h2 className="display">Desbloquear conteúdo</h2>
        {imageToUnlock && <p className="text-muted">Comprando acesso a: <strong>{imageToUnlock.title}</strong></p>}

        <div className="checkout-modal__method">
          <button className={`chip ${method === 'stripe' ? 'chip--active' : ''}`} onClick={() => setMethod('stripe')}>Cartão (Stripe)</button>
          <button className={`chip ${method === 'mercadopago' ? 'chip--active' : ''}`} onClick={() => setMethod('mercadopago')}>Pix / Mercado Pago</button>
        </div>

        {imageToUnlock && (
          <div className="checkout-section">
            <h4>Compra avulsa</h4>
            <button className="btn btn-premium btn-block" disabled={loadingId === 'single'}
              onClick={() => handleBuy({ id: 'single' }, 'single_image')}>
              {loadingId === 'single' ? 'Abrindo pagamento…' : `Comprar esta imagem`}
            </button>
          </div>
        )}

        <div className="checkout-section">
          <h4>Pacotes de créditos</h4>
          <div className="checkout-packs">
            {CREDIT_PACKS.map((pack) => (
              <button key={pack.id} className={`checkout-pack ${pack.highlight ? 'checkout-pack--highlight' : ''}`}
                disabled={loadingId === pack.id} onClick={() => handleBuy(pack, 'credits')}>
                <strong>{pack.label}</strong>
                <span className="mono">R$ {pack.price.toFixed(2)}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="checkout-section">
          <h4>Assinatura</h4>
          {PLANS.map((plan) => (
            <div key={plan.id} className="checkout-plan">
              <div>
                <strong>{plan.label}</strong>
                <ul className="checkout-plan__perks">
                  {plan.perks.map((p) => <li key={p}>{p}</li>)}
                </ul>
              </div>
              <button className="btn btn-primary" disabled={loadingId === plan.id} onClick={() => handleBuy(plan, 'subscription')}>
                R$ {plan.price.toFixed(2)}/{plan.interval}
              </button>
            </div>
          ))}
        </div>

        {error && <p className="error-text">{error}</p>}
      </div>
    </div>
  )
}
