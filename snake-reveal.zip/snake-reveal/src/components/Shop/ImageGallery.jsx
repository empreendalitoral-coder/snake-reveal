import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { useAuth } from '../../context/AuthContext.jsx'
import ImageCard from './ImageCard.jsx'

export default function ImageGallery() {
  const { user } = useAuth()
  const [images, setImages] = useState([])
  const [categories, setCategories] = useState([])
  const [unlockedIds, setUnlockedIds] = useState(new Set())
  const [activeCategory, setActiveCategory] = useState('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      setLoading(true)
      const [{ data: imgs }, { data: cats }] = await Promise.all([
        supabase
          .from('images')
          .select('id, title, thumbnail_url, access_tier, price_credits, category_id, categories(name), is_published')
          .eq('is_published', true)
          .order('created_at', { ascending: false }),
        supabase.from('categories').select('id, name').order('name')
      ])

      setImages((imgs || []).map((i) => ({ ...i, category_name: i.categories?.name })))
      setCategories(cats || [])

      if (user) {
        const { data: purchases } = await supabase
          .from('purchases')
          .select('image_id')
          .eq('user_id', user.id)
        setUnlockedIds(new Set((purchases || []).map((p) => p.image_id)))
      }
      setLoading(false)
    })()
  }, [user])

  const filtered = useMemo(() => {
    if (activeCategory === 'all') return images
    return images.filter((i) => i.category_id === activeCategory)
  }, [images, activeCategory])

  if (loading) return <div className="page-loading">Carregando galeria…</div>

  return (
    <div className="gallery">
      <div className="gallery__filters">
        <button className={`chip ${activeCategory === 'all' ? 'chip--active' : ''}`} onClick={() => setActiveCategory('all')}>
          Todas
        </button>
        {categories.map((c) => (
          <button key={c.id} className={`chip ${activeCategory === c.id ? 'chip--active' : ''}`} onClick={() => setActiveCategory(c.id)}>
            {c.name}
          </button>
        ))}
      </div>

      <div className="grid gallery__grid">
        {filtered.map((img) => (
          <ImageCard key={img.id} image={img} unlocked={unlockedIds.has(img.id)} />
        ))}
        {filtered.length === 0 && <p className="text-muted">Nenhuma imagem nesta categoria ainda.</p>}
      </div>
    </div>
  )
}
