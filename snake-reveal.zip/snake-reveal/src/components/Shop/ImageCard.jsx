import { Link } from 'react-router-dom'

export default function ImageCard({ image, unlocked }) {
  const isFree = image.access_tier === 'free'
  const canPlay = isFree || unlocked

  return (
    <div className="image-card card">
      <div className="image-card__thumb-wrap">
        <img src={image.thumbnail_url} alt={image.title} className="image-card__thumb" loading="lazy" />
        {!canPlay && <div className="image-card__lock">🔒</div>}
        <span className={`badge ${isFree ? 'badge-free' : 'badge-premium'} image-card__badge`}>
          {isFree ? 'Grátis' : 'Premium'}
        </span>
      </div>

      <div className="image-card__body">
        <h3 className="image-card__title">{image.title}</h3>
        <p className="image-card__category mono">{image.category_name}</p>

        {canPlay ? (
          <Link to={`/jogar/${image.id}`} className="btn btn-primary btn-sm btn-block">Jogar</Link>
        ) : (
          <Link to={`/jogar/${image.id}`} className="btn btn-premium btn-sm btn-block">
            Desbloquear {image.price_credits ? `· ${image.price_credits} 💠` : ''}
          </Link>
        )}
      </div>
    </div>
  )
}
