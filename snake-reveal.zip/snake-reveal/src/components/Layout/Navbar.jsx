import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'

export default function Navbar() {
  const { user, profile, isAdmin, signOut } = useAuth()

  return (
    <header className="navbar">
      <Link to="/" className="navbar__brand display">
        <span className="navbar__brand-dot" /> Snake Reveal
      </Link>

      <nav className="navbar__links">
        <NavLink to="/galeria" className="navbar__link">Galeria</NavLink>
        {user && <NavLink to="/jogar" className="navbar__link">Jogar</NavLink>}
        {isAdmin && <NavLink to="/admin" className="navbar__link navbar__link--admin">Admin</NavLink>}
      </nav>

      <div className="navbar__actions">
        {user ? (
          <>
            <span className="navbar__credits mono" title="Seus créditos">
              💠 {profile?.credits ?? 0}
            </span>
            <Link to="/perfil" className="btn btn-ghost btn-sm">{profile?.display_name || 'Perfil'}</Link>
            <button className="btn btn-sm" onClick={signOut}>Sair</button>
          </>
        ) : (
          <>
            <Link to="/entrar" className="btn btn-ghost btn-sm">Entrar</Link>
            <Link to="/cadastro" className="btn btn-primary btn-sm">Criar conta</Link>
          </>
        )}
      </div>
    </header>
  )
}
