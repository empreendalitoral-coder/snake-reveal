import { DIRS } from './useSnakeGame.js'

/** Controles em tela (D-pad) para touch — essencial no mobile. */
export default function GameControls({ onDirection, onPauseToggle, isPaused }) {
  return (
    <div className="game-controls">
      <div className="dpad">
        <button className="dpad__btn dpad__up" aria-label="Cima" onClick={() => onDirection(DIRS.UP)}>▲</button>
        <button className="dpad__btn dpad__left" aria-label="Esquerda" onClick={() => onDirection(DIRS.LEFT)}>◀</button>
        <button className="dpad__btn dpad__pause" aria-label="Pausar" onClick={onPauseToggle}>{isPaused ? '▶' : '❙❙'}</button>
        <button className="dpad__btn dpad__right" aria-label="Direita" onClick={() => onDirection(DIRS.RIGHT)}>▶</button>
        <button className="dpad__btn dpad__down" aria-label="Baixo" onClick={() => onDirection(DIRS.DOWN)}>▼</button>
      </div>
    </div>
  )
}
