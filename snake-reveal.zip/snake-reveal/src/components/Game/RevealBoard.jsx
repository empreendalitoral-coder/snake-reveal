import { useMemo } from 'react'

/**
 * Renderiza o tabuleiro: a imagem-alvo fica "por baixo", coberta por
 * uma grade de tiles opacos. Cada tile visitado pela cobra vira
 * transparente (com uma pequena transição), revelando a imagem.
 * A cobra e a comida são desenhadas por cima em posição absoluta.
 */
export default function RevealBoard({ imageUrl, gridSize, snake, food, revealed, blurredPreviewUrl }) {
  const cells = useMemo(() => {
    const arr = []
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) arr.push({ x, y })
    }
    return arr
  }, [gridSize])

  return (
    <div className="reveal-board" style={{ '--grid-size': gridSize }}>
      <div
        className="reveal-board__image"
        style={{ backgroundImage: `url(${blurredPreviewUrl || imageUrl})` }}
        aria-hidden="true"
      />
      <div
        className="reveal-board__image reveal-board__image--sharp"
        style={{ backgroundImage: `url(${imageUrl})` }}
        aria-hidden="true"
      />

      <div className="reveal-board__grid">
        {cells.map(({ x, y }) => {
          const isRevealed = revealed.has(`${x}:${y}`)
          return (
            <div
              key={`${x}:${y}`}
              className={`reveal-tile ${isRevealed ? 'is-revealed' : ''}`}
              style={{ gridColumnStart: x + 1, gridRowStart: y + 1 }}
            />
          )
        })}

        {snake.map((seg, i) => (
          <div
            key={`${seg.x}:${seg.y}:${i}`}
            className={`snake-seg ${i === 0 ? 'snake-head' : ''}`}
            style={{ gridColumnStart: seg.x + 1, gridRowStart: seg.y + 1 }}
          />
        ))}

        <div className="food-dot" style={{ gridColumnStart: food.x + 1, gridRowStart: food.y + 1 }} />
      </div>
    </div>
  )
}
