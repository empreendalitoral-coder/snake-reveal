import { useEffect, useCallback } from 'react'
import { useSnakeGame, DIRS } from './useSnakeGame.js'
import RevealBoard from './RevealBoard.jsx'
import GameHud from './GameHud.jsx'
import GameControls from './GameControls.jsx'
import './reveal-board.css'
import './game-controls.css'

const KEY_MAP = {
  ArrowUp: DIRS.UP, w: DIRS.UP, W: DIRS.UP,
  ArrowDown: DIRS.DOWN, s: DIRS.DOWN, S: DIRS.DOWN,
  ArrowLeft: DIRS.LEFT, a: DIRS.LEFT, A: DIRS.LEFT,
  ArrowRight: DIRS.RIGHT, d: DIRS.RIGHT, D: DIRS.RIGHT
}

/**
 * Componente de alto nível do jogo. Recebe a imagem-alvo (já resolvida
 * pelo caller a partir de permissões — grátis ou comprada) e dispara
 * onWin quando o jogador revela o suficiente, para então persistir o
 * progresso/desbloqueio no Supabase.
 */
export default function SnakeGame({ image, onWin, onProgressChange, difficulty = 'normal' }) {
  const settings = DIFFICULTY[difficulty] ?? DIFFICULTY.normal

  const game = useSnakeGame({
    gridSize: settings.gridSize,
    tickMs: settings.tickMs,
    revealGoal: settings.revealGoal,
    onWin: () => onWin?.(game_score_ref.current)
  })

  // Referência simples para pegar o score atual dentro do callback onWin
  const game_score_ref = { current: game.score }
  useEffect(() => { game_score_ref.current = game.score })

  useEffect(() => {
    onProgressChange?.(game.revealProgress)
  }, [game.revealProgress, onProgressChange])

  const handleKey = useCallback((e) => {
    const dir = KEY_MAP[e.key]
    if (!dir) return
    e.preventDefault()
    game.setDirection(dir)
    if (game.status === 'idle') game.start()
  }, [game])

  useEffect(() => {
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [handleKey])

  const handleDpad = (dir) => {
    game.setDirection(dir)
    if (game.status === 'idle') game.start()
  }

  return (
    <div className="snake-game">
      <GameHud score={game.score} revealProgress={game.revealProgress} status={game.status} />

      <RevealBoard
        imageUrl={image.fullUrl}
        blurredPreviewUrl={image.blurredPreviewUrl}
        gridSize={game.gridSize}
        snake={game.snake}
        food={game.food}
        revealed={game.revealed}
      />

      {game.status === 'idle' && (
        <div className="game-overlay-hint">
          <p>Use as setas / WASD ou o D-pad para começar a mover a cobra.</p>
        </div>
      )}

      {game.status === 'lost' && (
        <div className="game-overlay-hint">
          <p>Você bateu em si mesmo. Tente novamente!</p>
          <button className="btn btn-primary" onClick={game.reset}>Jogar novamente</button>
        </div>
      )}

      {game.status === 'won' && (
        <div className="game-overlay-hint">
          <p>Imagem revelada! 🎉</p>
          <button className="btn btn-primary" onClick={game.reset}>Jogar de novo</button>
        </div>
      )}

      <GameControls
        onDirection={handleDpad}
        onPauseToggle={() => (game.status === 'paused' ? game.resume() : game.pause())}
        isPaused={game.status === 'paused'}
      />
    </div>
  )
}

const DIFFICULTY = {
  facil:  { gridSize: 14, tickMs: 170, revealGoal: 0.45 },
  normal: { gridSize: 18, tickMs: 140, revealGoal: 0.55 },
  dificil:{ gridSize: 22, tickMs: 110, revealGoal: 0.65 }
}
