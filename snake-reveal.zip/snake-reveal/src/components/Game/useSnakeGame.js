import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * Motor do jogo Snake com mecânica de "revelação de imagem".
 * Cada célula do tabuleiro visitada pela cobra fica permanentemente
 * revelada (mesmo depois que a cobra se move para longe), até que
 * a % de revelação atinja o objetivo ou o jogador perca.
 *
 * Retorna estado pronto para renderização + função de progresso (0-1)
 * usada pelo componente visual para recortar a imagem.
 */
const DIRS = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 }
}

export function useSnakeGame({
  gridSize = 18,
  tickMs = 140,
  revealGoal = 0.55, // % do tabuleiro a revelar para "vencer" e desbloquear a imagem
  onWin,
  onLose
} = {}) {
  const center = Math.floor(gridSize / 2)
  const initialSnake = [{ x: center, y: center }, { x: center - 1, y: center }, { x: center - 2, y: center }]

  const [snake, setSnake] = useState(initialSnake)
  const [direction, setDirection] = useState(DIRS.RIGHT)
  const [food, setFood] = useState(() => randomEmptyCell(initialSnake, gridSize))
  const [revealed, setRevealed] = useState(() => new Set(initialSnake.map(cellKey)))
  const [status, setStatus] = useState('idle') // idle | running | paused | won | lost
  const [score, setScore] = useState(0)

  const directionRef = useRef(direction)
  const queuedDirRef = useRef(null)
  const intervalRef = useRef(null)

  const totalCells = gridSize * gridSize
  const revealProgress = revealed.size / totalCells

  const reset = useCallback(() => {
    setSnake(initialSnake)
    setDirection(DIRS.RIGHT)
    directionRef.current = DIRS.RIGHT
    queuedDirRef.current = null
    setFood(randomEmptyCell(initialSnake, gridSize))
    setRevealed(new Set(initialSnake.map(cellKey)))
    setScore(0)
    setStatus('idle')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gridSize])

  const start = useCallback(() => setStatus('running'), [])
  const pause = useCallback(() => setStatus((s) => (s === 'running' ? 'paused' : s)), [])
  const resume = useCallback(() => setStatus((s) => (s === 'paused' ? 'running' : s)), [])

  const setDirectionSafe = useCallback((newDir) => {
    const current = directionRef.current
    // Impede reversão instantânea (morte por virar 180°)
    if (newDir.x === -current.x && newDir.y === -current.y) return
    queuedDirRef.current = newDir
  }, [])

  useEffect(() => {
    if (status !== 'running') {
      clearInterval(intervalRef.current)
      return
    }

    intervalRef.current = setInterval(() => {
      setSnake((prevSnake) => {
        const dir = queuedDirRef.current || directionRef.current
        directionRef.current = dir
        setDirection(dir)

        const head = prevSnake[0]
        const newHead = {
          x: (head.x + dir.x + gridSize) % gridSize, // tabuleiro toroidal (sem parede — mais acessível)
          y: (head.y + dir.y + gridSize) % gridSize
        }

        // Colisão com o próprio corpo = derrota
        const selfHit = prevSnake.some((seg, i) => i !== prevSnake.length - 1 && seg.x === newHead.x && seg.y === newHead.y)
        if (selfHit) {
          setStatus('lost')
          onLose?.()
          return prevSnake
        }

        const ateFood = newHead.x === food.x && newHead.y === food.y
        const newSnake = [newHead, ...prevSnake]
        if (!ateFood) newSnake.pop()
        else {
          setScore((s) => s + 10)
          setFood(randomEmptyCell(newSnake, gridSize))
        }

        setRevealed((prevRevealed) => {
          const next = new Set(prevRevealed)
          newSnake.forEach((seg) => next.add(cellKey(seg)))
          const progress = next.size / totalCells
          if (progress >= revealGoal) {
            setStatus('won')
            onWin?.()
          }
          return next
        })

        return newSnake
      })
    }, tickMs)

    return () => clearInterval(intervalRef.current)
  }, [status, food, gridSize, tickMs, revealGoal, totalCells, onWin, onLose])

  return {
    gridSize,
    snake,
    food,
    revealed,
    revealProgress,
    score,
    status,
    start,
    pause,
    resume,
    reset,
    setDirection: setDirectionSafe
  }
}

function cellKey(cell) { return `${cell.x}:${cell.y}` }

function randomEmptyCell(occupiedList, gridSize) {
  const occupied = new Set(occupiedList.map(cellKey))
  let cell
  do {
    cell = { x: Math.floor(Math.random() * gridSize), y: Math.floor(Math.random() * gridSize) }
  } while (occupied.has(cellKey(cell)))
  return cell
}

export { DIRS }
