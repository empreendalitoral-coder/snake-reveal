export default function GameHud({ score, revealProgress, status }) {
  const pct = Math.min(100, Math.round(revealProgress * 100))
  return (
    <div className="game-hud">
      <div className="game-hud__row">
        <span className="mono game-hud__score">SCORE {String(score).padStart(4, '0')}</span>
        <span className="mono game-hud__status">{statusLabel(status)}</span>
      </div>
      <div className="progress-bar" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="progress-bar__fill" style={{ width: `${pct}%` }} />
      </div>
      <span className="mono game-hud__pct">{pct}% revelado</span>
    </div>
  )
}

function statusLabel(status) {
  switch (status) {
    case 'running': return '● JOGANDO'
    case 'paused': return '❙❙ PAUSADO'
    case 'won': return '★ REVELADO'
    case 'lost': return '✕ FIM DE JOGO'
    default: return '○ PRONTO'
  }
}
