import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

/**
 * CRUD de imagens: upload para o bucket `images` do Supabase Storage,
 * gera thumbnail (o processamento pesado fica a cargo de uma Edge
 * Function/Storage transform em produção — aqui usamos a mesma imagem
 * redimensionada via URL de transformação do Supabase), e grava metadados
 * (categoria, tier grátis/premium, preço) na tabela `images`.
 */
export default function ImageUpload() {
  const [images, setImages] = useState([])
  const [categories, setCategories] = useState([])
  const [form, setForm] = useState({ title: '', category_id: '', access_tier: 'free', price_credits: 0 })
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState('')

  const loadAll = async () => {
    const [{ data: imgs }, { data: cats }] = await Promise.all([
      supabase.from('images').select('*, categories(name)').order('created_at', { ascending: false }),
      supabase.from('categories').select('id, name').order('name')
    ])
    setImages(imgs || [])
    setCategories(cats || [])
  }

  useEffect(() => { loadAll() }, [])

  const handleUpload = async (e) => {
    e.preventDefault()
    setError('')
    if (!file) { setError('Selecione um arquivo de imagem.'); return }
    setUploading(true)
    try {
      const ext = file.name.split('.').pop()
      const path = `originals/${crypto.randomUUID()}.${ext}`

      const { error: uploadError } = await supabase.storage.from('images').upload(path, file, {
        cacheControl: '31536000',
        upsert: false
      })
      if (uploadError) throw uploadError

      const { data: pub } = supabase.storage.from('images').getPublicUrl(path)
      const fullUrl = pub.publicUrl
      // Transformação de thumbnail via Supabase Image Transform (plano Pro)
      const thumbUrl = `${fullUrl}?width=400&height=400&resize=cover&quality=70`

      const { error: insertError } = await supabase.from('images').insert({
        title: form.title,
        category_id: form.category_id || null,
        access_tier: form.access_tier,
        price_credits: form.access_tier === 'premium' ? Number(form.price_credits) : 0,
        full_url: fullUrl,
        thumbnail_url: thumbUrl,
        storage_path: path,
        is_published: true
      })
      if (insertError) throw insertError

      setForm({ title: '', category_id: '', access_tier: 'free', price_credits: 0 })
      setFile(null)
      await loadAll()
    } catch (err) {
      console.error(err)
      setError('Falha no upload. Verifique o arquivo e tente novamente.')
    } finally {
      setUploading(false)
    }
  }

  const togglePublish = async (img) => {
    await supabase.from('images').update({ is_published: !img.is_published }).eq('id', img.id)
    loadAll()
  }

  const removeImage = async (img) => {
    if (!confirm(`Remover "${img.title}"? Isso não pode ser desfeito.`)) return
    await supabase.storage.from('images').remove([img.storage_path])
    await supabase.from('images').delete().eq('id', img.id)
    loadAll()
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: 20 }}>
        <h3>Nova imagem</h3>
        <form onSubmit={handleUpload}>
          <div className="admin-form-row">
            <div className="field">
              <label>Título</label>
              <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="field">
              <label>Categoria</label>
              <select value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })}>
                <option value="">Sem categoria</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          </div>
          <div className="admin-form-row">
            <div className="field">
              <label>Tipo de acesso</label>
              <select value={form.access_tier} onChange={(e) => setForm({ ...form, access_tier: e.target.value })}>
                <option value="free">Grátis</option>
                <option value="premium">Premium</option>
              </select>
            </div>
            {form.access_tier === 'premium' && (
              <div className="field">
                <label>Preço (créditos)</label>
                <input type="number" min="1" value={form.price_credits} onChange={(e) => setForm({ ...form, price_credits: e.target.value })} />
              </div>
            )}
          </div>
          <div className="field">
            <label>Arquivo de imagem</label>
            <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files[0])} required />
          </div>
          {error && <p className="error-text">{error}</p>}
          <button className="btn btn-primary" disabled={uploading}>{uploading ? 'Enviando…' : 'Enviar imagem'}</button>
        </form>
      </div>

      <div className="card">
        <h3>Imagens cadastradas</h3>
        <table className="admin-table">
          <thead><tr><th></th><th>Título</th><th>Categoria</th><th>Acesso</th><th>Publicada</th><th></th></tr></thead>
          <tbody>
            {images.map((img) => (
              <tr key={img.id}>
                <td><img src={img.thumbnail_url} alt="" style={{ width: 40, height: 40, objectFit: 'cover', borderRadius: 6 }} /></td>
                <td>{img.title}</td>
                <td>{img.categories?.name ?? '—'}</td>
                <td><span className={`badge ${img.access_tier === 'free' ? 'badge-free' : 'badge-premium'}`}>{img.access_tier}</span></td>
                <td>
                  <button className="btn btn-ghost btn-sm" onClick={() => togglePublish(img)}>
                    {img.is_published ? 'Publicada' : 'Oculta'}
                  </button>
                </td>
                <td><button className="btn btn-danger btn-sm" onClick={() => removeImage(img)}>Remover</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
