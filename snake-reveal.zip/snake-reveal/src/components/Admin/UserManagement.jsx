import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

/**
 * Gerenciamento de usuários: busca, concessão manual de créditos,
 * promoção a admin e bloqueio de conta (flag `is_blocked`, checada
 * nas policies de RLS para impedir login efetivo de contas banidas).
 */
export default function UserManagement() {
  const [users, setUsers] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    let query = supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(100)
    if (search) query = query.ilike('display_name', `%${search}%`)
    const { data } = await query
    setUsers(data || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [search]) // eslint-disable-line react-hooks/exhaustive-deps

  const grantCredits = async (user) => {
    const amountStr = prompt(`Quantos créditos adicionar para ${user.display_name}?`, '10')
    const amount = Number(amountStr)
    if (!amount) return
    await supabase.from('profiles').update({ credits: (user.credits ?? 0) + amount }).eq('id', user.id)
    load()
  }

  const toggleRole = async (user) => {
    const newRole = user.role === 'admin' ? 'user' : 'admin'
    if (!confirm(`Tornar ${user.display_name} ${newRole === 'admin' ? 'administrador' : 'usuário comum'}?`)) return
    await supabase.from('profiles').update({ role: newRole }).eq('id', user.id)
    load()
  }

  const toggleBlock = async (user) => {
    await supabase.from('profiles').update({ is_blocked: !user.is_blocked }).eq('id', user.id)
    load()
  }

  return (
    <div className="card">
      <div className="admin-toolbar">
        <h3 style={{ margin: 0 }}>Usuários</h3>
        <input placeholder="Buscar por nome…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ maxWidth: 220 }} />
      </div>

      {loading ? <p className="text-muted">Carregando…</p> : (
        <table className="admin-table">
          <thead><tr><th>Nome</th><th>Créditos</th><th>Papel</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.display_name}</td>
                <td className="mono">{u.credits ?? 0}</td>
                <td>
                  <span className={`badge ${u.role === 'admin' ? 'badge-premium' : 'badge-free'}`}>{u.role}</span>
                </td>
                <td>{u.is_blocked ? <span className="badge" style={{ background: 'rgba(255,107,107,0.15)', color: 'var(--danger)' }}>Bloqueado</span> : 'Ativo'}</td>
                <td style={{ display: 'flex', gap: 6 }}>
                  <button className="btn btn-ghost btn-sm" onClick={() => grantCredits(u)}>+ créditos</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => toggleRole(u)}>{u.role === 'admin' ? 'Rebaixar' : 'Tornar admin'}</button>
                  <button className="btn btn-danger btn-sm" onClick={() => toggleBlock(u)}>{u.is_blocked ? 'Desbloquear' : 'Bloquear'}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}
