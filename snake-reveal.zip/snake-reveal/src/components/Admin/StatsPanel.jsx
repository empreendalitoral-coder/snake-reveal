import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

/**
 * Lê da view `admin_stats_summary` (ver supabase/migrations) — agrega
 * receita, usuários ativos, imagens mais jogadas etc. em SQL, evitando
 * puxar tabelas inteiras para o cliente.
 */
export default function StatsPanel() {
  const [summary, setSummary] = useState(null)
  const [topImages, setTopImages] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      const [{ data: s }, { data: top }] = await Promise.all([
        supabase.from('admin_stats_summary').select('*').single(),
        supabase.from('admin_top_images').select('*').limit(5)
      ])
      setSummary(s)
      setTopImages(top || [])
      setLoading(false)
    })()
  }, [])

  if (loading) return <p className="text-muted">Carregando estatísticas…</p>

  const cards = [
    { label: 'Usuários totais', value: summary?.total_users ?? 0 },
    { label: 'Novos (7 dias)', value: summary?.new_users_7d ?? 0 },
    { label: 'Assinaturas ativas', value: summary?.active_subscriptions ?? 0 },
    { label: 'Receita (30 dias)', value: `R$ ${Number(summary?.revenue_30d ?? 0).toFixed(2)}` },
    { label: 'Partidas jogadas', value: summary?.total_sessions ?? 0 },
    { label: 'Imagens publicadas', value: summary?.total_images ?? 0 }
  ]

  return (
    <div>
      <div className="admin-stat-grid">
        {cards.map((c) => (
          <div key={c.label} className="card admin-stat-card">
            <strong>{c.value}</strong>
            <span>{c.label}</span>
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Imagens mais jogadas</h3>
        <table className="admin-table">
          <thead>
            <tr><th>Imagem</th><th>Sessões</th><th>Compras</th><th>Receita</th></tr>
          </thead>
          <tbody>
            {topImages.map((row) => (
              <tr key={row.image_id}>
                <td>{row.title}</td>
                <td>{row.sessions_count}</td>
                <td>{row.purchase_count}</td>
                <td>R$ {Number(row.revenue).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
