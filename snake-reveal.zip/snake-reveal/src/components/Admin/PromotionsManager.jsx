import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

/**
 * Promoções: descontos por % aplicados a pacotes de crédito/assinatura
 * ou a uma imagem específica, com janela de validade. A Edge Function
 * `create-checkout` consulta promoções ativas ao montar o preço final.
 */
export default function PromotionsManager() {
  const [promos, setPromos] = useState([])
  const [form, setForm] = useState({ code: '', discount_pct: 10, starts_at: '', ends_at: '', active: true })

  const load = async () => {
    const { data } = await supabase.from('promotions').select('*').order('created_at', { ascending: false })
    setPromos(data || [])
  }
  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    await supabase.from('promotions').insert({
      code: form.code.toUpperCase(),
      discount_pct: Number(form.discount_pct),
      starts_at: form.starts_at || null,
      ends_at: form.ends_at || null,
      active: form.active
    })
    setForm({ code: '', discount_pct: 10, starts_at: '', ends_at: '', active: true })
    load()
  }

  const toggleActive = async (promo) => {
    await supabase.from('promotions').update({ active: !promo.active }).eq('id', promo.id)
    load()
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: 20 }}>
        <h3>Nova promoção</h3>
        <form onSubmit={handleSubmit}>
          <div className="admin-form-row">
            <div className="field">
              <label>Código (cupom)</label>
              <input required value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="Ex: BEMVINDO10" />
            </div>
            <div className="field">
              <label>Desconto (%)</label>
              <input type="number" min="1" max="90" required value={form.discount_pct} onChange={(e) => setForm({ ...form, discount_pct: e.target.value })} />
            </div>
          </div>
          <div className="admin-form-row">
            <div className="field">
              <label>Início</label>
              <input type="date" value={form.starts_at} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} />
            </div>
            <div className="field">
              <label>Término</label>
              <input type="date" value={form.ends_at} onChange={(e) => setForm({ ...form, ends_at: e.target.value })} />
            </div>
          </div>
          <button className="btn btn-primary">Criar promoção</button>
        </form>
      </div>

      <div className="card">
        <h3>Promoções cadastradas</h3>
        <table className="admin-table">
          <thead><tr><th>Código</th><th>Desconto</th><th>Vigência</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {promos.map((p) => (
              <tr key={p.id}>
                <td className="mono">{p.code}</td>
                <td>{p.discount_pct}%</td>
                <td className="mono">{p.starts_at ?? '—'} → {p.ends_at ?? '—'}</td>
                <td>{p.active ? 'Ativa' : 'Inativa'}</td>
                <td><button className="btn btn-ghost btn-sm" onClick={() => toggleActive(p)}>{p.active ? 'Desativar' : 'Ativar'}</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
