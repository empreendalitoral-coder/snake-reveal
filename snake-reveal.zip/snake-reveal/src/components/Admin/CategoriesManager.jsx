import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

export default function CategoriesManager() {
  const [categories, setCategories] = useState([])
  const [name, setName] = useState('')

  const load = async () => {
    const { data } = await supabase.from('categories').select('id, name, images(count)').order('name')
    setCategories(data || [])
  }
  useEffect(() => { load() }, [])

  const addCategory = async (e) => {
    e.preventDefault()
    if (!name.trim()) return
    await supabase.from('categories').insert({ name: name.trim() })
    setName('')
    load()
  }

  const rename = async (cat) => {
    const newName = prompt('Novo nome da categoria:', cat.name)
    if (!newName || newName === cat.name) return
    await supabase.from('categories').update({ name: newName }).eq('id', cat.id)
    load()
  }

  const remove = async (cat) => {
    if (!confirm(`Excluir a categoria "${cat.name}"? As imagens ficam sem categoria.`)) return
    await supabase.from('categories').delete().eq('id', cat.id)
    load()
  }

  return (
    <div className="card">
      <h3>Categorias</h3>
      <form onSubmit={addCategory} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input placeholder="Nova categoria" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn btn-primary btn-sm">Adicionar</button>
      </form>

      <table className="admin-table">
        <thead><tr><th>Nome</th><th>Imagens</th><th></th></tr></thead>
        <tbody>
          {categories.map((c) => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td className="mono">{c.images?.[0]?.count ?? 0}</td>
              <td style={{ display: 'flex', gap: 6 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => rename(c)}>Renomear</button>
                <button className="btn btn-danger btn-sm" onClick={() => remove(c)}>Excluir</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
