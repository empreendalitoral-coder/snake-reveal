import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Layout/Navbar.jsx'
import ProtectedRoute from './components/Layout/ProtectedRoute.jsx'
import AdminRoute from './components/Layout/AdminRoute.jsx'

import Home from './pages/Home.jsx'
import Play from './pages/Play.jsx'
import Gallery from './pages/Gallery.jsx'
import Profile from './pages/Profile.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Admin from './pages/Admin.jsx'
import NotFound from './pages/NotFound.jsx'

export default function App() {
  return (
    <div className="app-shell">
      <Navbar />
      <main className="app-main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/galeria" element={<Gallery />} />
          <Route path="/entrar" element={<Login />} />
          <Route path="/cadastro" element={<Register />} />

          <Route path="/jogar/:imageId?" element={
            <ProtectedRoute><Play /></ProtectedRoute>
          } />
          <Route path="/perfil" element={
            <ProtectedRoute><Profile /></ProtectedRoute>
          } />

          <Route path="/admin/*" element={
            <AdminRoute><Admin /></AdminRoute>
          } />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </div>
  )
}
