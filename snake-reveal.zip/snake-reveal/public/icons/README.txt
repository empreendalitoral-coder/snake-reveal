Coloque aqui: icon-192.png, icon-512.png, icon-512-maskable.png
(e um apple-touch-icon.png em /public)
