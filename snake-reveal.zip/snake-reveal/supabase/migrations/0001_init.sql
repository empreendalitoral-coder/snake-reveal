-- ============================================================
-- SNAKE REVEAL — Schema inicial do Supabase
-- Rode este arquivo no SQL Editor do seu projeto Supabase,
-- ou via `supabase db push` com a CLI.
-- ============================================================

-- Extensões
create extension if not exists "pgcrypto";

-- ---------- PROFILES ----------
-- Espelha auth.users com dados de app: role, créditos, bloqueio.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Jogador',
  role text not null default 'user' check (role in ('user', 'admin')),
  credits integer not null default 0,
  is_blocked boolean not null default false,
  created_at timestamptz not null default now()
);

-- Cria o profile automaticamente quando um usuário se cadastra
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', 'Jogador'));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ---------- CATEGORIES ----------
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

-- ---------- IMAGES ----------
create table if not exists public.images (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category_id uuid references public.categories(id) on delete set null,
  access_tier text not null default 'free' check (access_tier in ('free', 'premium')),
  price_credits integer not null default 0,
  full_url text not null,
  thumbnail_url text not null,
  storage_path text not null,
  is_published boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- ---------- PURCHASES (compras avulsas e pacotes de crédito) ----------
create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  image_id uuid references public.images(id) on delete set null, -- null = pacote de créditos
  provider text not null check (provider in ('stripe', 'mercadopago')),
  provider_reference text not null, -- id da sessão/pagamento no provedor
  amount_paid numeric(10,2) not null,
  currency text not null default 'BRL',
  credits_granted integer not null default 0,
  status text not null default 'completed' check (status in ('pending', 'completed', 'refunded', 'failed')),
  created_at timestamptz not null default now(),
  unique (provider, provider_reference)
);

-- ---------- SUBSCRIPTIONS ----------
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null check (provider in ('stripe', 'mercadopago')),
  provider_subscription_id text not null unique,
  plan_id text not null,
  status text not null check (status in ('active', 'canceled', 'past_due', 'trialing')),
  current_period_end timestamptz,
  created_at timestamptz not null default now()
);

-- ---------- PROMOTIONS ----------
create table if not exists public.promotions (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_pct integer not null check (discount_pct between 1 and 90),
  starts_at date,
  ends_at date,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- GAME SESSIONS (progresso/partidas) ----------
create table if not exists public.game_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  image_id uuid not null references public.images(id) on delete cascade,
  score integer not null default 0,
  completed boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_images_category on public.images(category_id);
create index if not exists idx_purchases_user on public.purchases(user_id);
create index if not exists idx_sessions_user on public.game_sessions(user_id);
create index if not exists idx_sessions_image on public.game_sessions(image_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.images enable row level security;
alter table public.purchases enable row level security;
alter table public.subscriptions enable row level security;
alter table public.promotions enable row level security;
alter table public.game_sessions enable row level security;

-- Helper: usuário atual é admin?
create or replace function public.is_admin()
returns boolean as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql security definer stable;

-- PROFILES: usuário vê/edita o próprio; admin vê/edita todos
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
  for select using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin" on public.profiles
  for update using (id = auth.uid() or public.is_admin());

-- CATEGORIES: leitura pública, escrita só admin
drop policy if exists "categories_select_all" on public.categories;
create policy "categories_select_all" on public.categories for select using (true);
drop policy if exists "categories_write_admin" on public.categories;
create policy "categories_write_admin" on public.categories for all using (public.is_admin()) with check (public.is_admin());

-- IMAGES: leitura pública das publicadas; admin vê/edita tudo
drop policy if exists "images_select_published" on public.images;
create policy "images_select_published" on public.images
  for select using (is_published = true or public.is_admin());
drop policy if exists "images_write_admin" on public.images;
create policy "images_write_admin" on public.images
  for all using (public.is_admin()) with check (public.is_admin());

-- PURCHASES: usuário vê as próprias; admin vê todas. Inserção só via
-- service role (Edge Function do webhook), nunca direto do cliente.
drop policy if exists "purchases_select_own_or_admin" on public.purchases;
create policy "purchases_select_own_or_admin" on public.purchases
  for select using (user_id = auth.uid() or public.is_admin());

-- SUBSCRIPTIONS: mesmo padrão de purchases
drop policy if exists "subscriptions_select_own_or_admin" on public.subscriptions;
create policy "subscriptions_select_own_or_admin" on public.subscriptions
  for select using (user_id = auth.uid() or public.is_admin());

-- PROMOTIONS: leitura pública das ativas; escrita só admin
drop policy if exists "promotions_select_active_or_admin" on public.promotions;
create policy "promotions_select_active_or_admin" on public.promotions
  for select using (active = true or public.is_admin());
drop policy if exists "promotions_write_admin" on public.promotions;
create policy "promotions_write_admin" on public.promotions
  for all using (public.is_admin()) with check (public.is_admin());

-- GAME_SESSIONS: usuário só mexe nas próprias; admin vê todas
drop policy if exists "sessions_select_own_or_admin" on public.game_sessions;
create policy "sessions_select_own_or_admin" on public.game_sessions
  for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "sessions_insert_own" on public.game_sessions;
create policy "sessions_insert_own" on public.game_sessions
  for insert with check (user_id = auth.uid());

-- ============================================================
-- VIEWS DE ESTATÍSTICAS (usadas pelo painel admin)
-- ============================================================
create or replace view public.admin_stats_summary as
select
  (select count(*) from public.profiles) as total_users,
  (select count(*) from public.profiles where created_at > now() - interval '7 days') as new_users_7d,
  (select count(*) from public.subscriptions where status = 'active') as active_subscriptions,
  (select coalesce(sum(amount_paid), 0) from public.purchases where created_at > now() - interval '30 days' and status = 'completed') as revenue_30d,
  (select count(*) from public.game_sessions) as total_sessions,
  (select count(*) from public.images where is_published = true) as total_images;

create or replace view public.admin_top_images as
select
  i.id as image_id,
  i.title,
  count(distinct gs.id) as sessions_count,
  count(distinct p.id) as purchase_count,
  coalesce(sum(p.amount_paid), 0) as revenue
from public.images i
left join public.game_sessions gs on gs.image_id = i.id
left join public.purchases p on p.image_id = i.id and p.status = 'completed'
group by i.id, i.title
order by sessions_count desc;

-- Views de admin só devem ser lidas por admins (RLS de tabelas base já
-- restringe, mas reforçamos aqui negando acesso direto a não-admins
-- via security_invoker, disponível no Postgres 15+ do Supabase).
alter view public.admin_stats_summary set (security_invoker = true);
alter view public.admin_top_images set (security_invoker = true);

-- ============================================================
-- STORAGE BUCKET
-- ============================================================
insert into storage.buckets (id, name, public)
values ('images', 'images', true)
on conflict (id) do nothing;

drop policy if exists "images_bucket_public_read" on storage.objects;
create policy "images_bucket_public_read" on storage.objects
  for select using (bucket_id = 'images');
drop policy if exists "images_bucket_admin_write" on storage.objects;
create policy "images_bucket_admin_write" on storage.objects
  for insert with check (bucket_id = 'images' and public.is_admin());
drop policy if exists "images_bucket_admin_delete" on storage.objects;
create policy "images_bucket_admin_delete" on storage.objects
  for delete using (bucket_id = 'images' and public.is_admin());
