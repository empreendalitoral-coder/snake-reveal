// Webhook do Mercado Pago: confirma pagamentos (notification_url).
// Deploy: supabase functions deploy mercadopago-webhook --no-verify-jwt

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'

const supabaseAdmin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
const MP_ACCESS_TOKEN = Deno.env.get('MP_ACCESS_TOKEN')!

serve(async (req) => {
  try {
    const url = new URL(req.url)
    const paymentId = url.searchParams.get('data.id') || url.searchParams.get('id')
    if (!paymentId) return new Response('ignorado', { status: 200 })

    const resp = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: { Authorization: `Bearer ${MP_ACCESS_TOKEN}` }
    })
    const payment = await resp.json()

    if (payment.status === 'approved') {
      const { userId, kind, credits, imageId } = payment.metadata ?? {}
      if (kind === 'credits') {
        const { data: profile } = await supabaseAdmin.from('profiles').select('credits').eq('id', userId).single()
        await supabaseAdmin.from('profiles').update({ credits: (profile?.credits ?? 0) + Number(credits) }).eq('id', userId)
      }
      await supabaseAdmin.from('purchases').insert({
        user_id: userId,
        image_id: imageId ?? null,
        provider: 'mercadopago',
        provider_reference: String(payment.id),
        amount_paid: payment.transaction_amount,
        currency: payment.currency_id ?? 'BRL',
        credits_granted: kind === 'credits' ? Number(credits) : 0,
        status: 'completed'
      })
    }

    return new Response('ok', { status: 200 })
  } catch (err) {
    console.error(err)
    return new Response('erro', { status: 500 })
  }
})
