// Webhook do Stripe: confirma pagamentos e credita compras/assinaturas.
// Deploy: supabase functions deploy stripe-webhook --no-verify-jwt
// Configure a URL https://SEU-PROJETO.functions.supabase.co/stripe-webhook
// no painel do Stripe (Developers → Webhooks), eventos:
//   checkout.session.completed, customer.subscription.updated,
//   customer.subscription.deleted

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'
import Stripe from 'https://esm.sh/stripe@16.2.0?target=deno'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2024-06-20' })
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!
const supabaseAdmin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

serve(async (req) => {
  const signature = req.headers.get('stripe-signature')!
  const body = await req.text()

  let event
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret)
  } catch (err) {
    console.error('Assinatura inválida:', err.message)
    return new Response('Assinatura inválida', { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object
    const { userId, kind, credits, imageId, planId } = session.metadata

    if (kind === 'credits') {
      await grantCredits(userId, Number(credits))
      await recordPurchase({ userId, provider: 'stripe', ref: session.id, amount: session.amount_total / 100, creditsGranted: Number(credits) })
    } else if (kind === 'single_image') {
      await recordPurchase({ userId, provider: 'stripe', ref: session.id, amount: session.amount_total / 100, imageId })
    } else if (kind === 'subscription') {
      await supabaseAdmin.from('subscriptions').insert({
        user_id: userId,
        provider: 'stripe',
        provider_subscription_id: session.subscription,
        plan_id: planId,
        status: 'active'
      })
    }
  }

  if (event.type === 'customer.subscription.deleted') {
    const sub = event.data.object
    await supabaseAdmin.from('subscriptions').update({ status: 'canceled' }).eq('provider_subscription_id', sub.id)
  }

  return new Response('ok', { status: 200 })
})

async function grantCredits(userId: string, amount: number) {
  const { data: profile } = await supabaseAdmin.from('profiles').select('credits').eq('id', userId).single()
  await supabaseAdmin.from('profiles').update({ credits: (profile?.credits ?? 0) + amount }).eq('id', userId)
}

async function recordPurchase({ userId, provider, ref, amount, creditsGranted = 0, imageId = null }) {
  await supabaseAdmin.from('purchases').insert({
    user_id: userId,
    image_id: imageId,
    provider,
    provider_reference: ref,
    amount_paid: amount,
    currency: 'BRL',
    credits_granted: creditsGranted,
    status: 'completed'
  })
}
