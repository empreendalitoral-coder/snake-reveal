// Supabase Edge Function: cria a sessão/preferência de checkout no
// provedor escolhido (Stripe ou Mercado Pago). Roda no backend, então
// as chaves secretas nunca ficam expostas no frontend.
//
// Deploy: supabase functions deploy create-checkout
// Secrets: supabase secrets set STRIPE_SECRET_KEY=... MP_ACCESS_TOKEN=...

import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'
import Stripe from 'https://esm.sh/stripe@16.2.0?target=deno'

const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')! // nunca exposta ao cliente
)

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2024-06-20' })
const APP_URL = Deno.env.get('APP_URL') ?? 'http://localhost:5173'

// Catálogo de preços — em produção, ler da tabela `products` gerenciada
// pelo admin em vez de constante fixa.
const CREDIT_PACKS: Record<string, { credits: number; price: number }> = {
  pack_10: { credits: 10, price: 9.9 },
  pack_30: { credits: 30, price: 24.9 },
  pack_100: { credits: 100, price: 69.9 }
}
const PLANS: Record<string, { price: number; stripePriceId: string }> = {
  plan_mensal: { price: 19.9, stripePriceId: Deno.env.get('STRIPE_PRICE_MENSAL') ?? '' }
}

serve(async (req) => {
  try {
    const { provider, kind, itemId, imageId, userId } = await req.json()

    // Autoriza apenas o próprio usuário autenticado a criar checkout para si
    const authHeader = req.headers.get('Authorization') ?? ''
    const { data: userData, error: authError } = await supabaseAdmin.auth.getUser(authHeader.replace('Bearer ', ''))
    if (authError || userData.user?.id !== userId) {
      return json({ error: 'Não autorizado' }, 401)
    }

    let amount = 0
    let description = ''
    let metadata: Record<string, string> = { userId, kind }

    if (kind === 'credits') {
      const pack = CREDIT_PACKS[itemId]
      if (!pack) return json({ error: 'Pacote inválido' }, 400)
      amount = pack.price
      description = `${pack.credits} créditos`
      metadata.credits = String(pack.credits)
    } else if (kind === 'single_image') {
      const { data: image } = await supabaseAdmin.from('images').select('*').eq('id', imageId).single()
      if (!image) return json({ error: 'Imagem não encontrada' }, 404)
      amount = (image.price_credits ?? 0) * 0.5 // exemplo: conversão crédito->preço; ajuste sua régua de preço real
      description = `Acesso: ${image.title}`
      metadata.imageId = imageId
    } else if (kind === 'subscription') {
      const plan = PLANS[itemId]
      if (!plan) return json({ error: 'Plano inválido' }, 400)
      amount = plan.price
      description = 'Assinatura mensal'
      metadata.planId = itemId
    } else {
      return json({ error: 'Tipo de compra inválido' }, 400)
    }

    if (provider === 'stripe') {
      const checkoutUrl = await createStripeSession({ kind, amount, description, metadata, planId: itemId })
      return json({ checkoutUrl })
    }
    if (provider === 'mercadopago') {
      const checkoutUrl = await createMercadoPagoPreference({ amount, description, metadata })
      return json({ checkoutUrl })
    }
    return json({ error: 'Provedor inválido' }, 400)
  } catch (err) {
    console.error(err)
    return json({ error: 'Erro interno' }, 500)
  }
})

async function createStripeSession({ kind, amount, description, metadata, planId }) {
  if (kind === 'subscription') {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: PLANS[planId].stripePriceId, quantity: 1 }],
      success_url: `${APP_URL}/perfil?checkout=sucesso`,
      cancel_url: `${APP_URL}/perfil?checkout=cancelado`,
      metadata
    })
    return session.url
  }

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{
      price_data: {
        currency: 'brl',
        product_data: { name: description },
        unit_amount: Math.round(amount * 100)
      },
      quantity: 1
    }],
    success_url: `${APP_URL}/perfil?checkout=sucesso`,
    cancel_url: `${APP_URL}/perfil?checkout=cancelado`,
    metadata
  })
  return session.url
}

async function createMercadoPagoPreference({ amount, description, metadata }) {
  const resp = await fetch('https://api.mercadopago.com/checkout/preferences', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${Deno.env.get('MP_ACCESS_TOKEN')}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      items: [{ title: description, quantity: 1, currency_id: 'BRL', unit_price: amount }],
      back_urls: {
        success: `${APP_URL}/perfil?checkout=sucesso`,
        failure: `${APP_URL}/perfil?checkout=cancelado`
      },
      auto_return: 'approved',
      metadata,
      notification_url: `${Deno.env.get('SUPABASE_URL')}/functions/v1/mercadopago-webhook`
    })
  })
  const data = await resp.json()
  return data.init_point
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
}
